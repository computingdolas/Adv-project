before running any script named "script.sh", run the following command before you do ./script.sh:

chmod u+x script.sh
