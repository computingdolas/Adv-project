#!/bin/bash

clear

make clean

make all