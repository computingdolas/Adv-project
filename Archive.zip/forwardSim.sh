#!/bin/bash

clear

#Running forwardSim
./forwardSim $1 $2