// Includes

#include <iostream>
#include <vector>
#include <map>
#include <string>
#include <fstream>
#include <sstream>
#include <list>
#include <boost/algorithm/string.hpp>
#include "Building.h"
#include "BuildingData.h"
#include "Unit.h"
#include "Race.h"

using namespace std;
using namespace boost::algorithm;

// class definition 

class Protoss : public Race
{

public:

	std::vector<Building> buildings_queue;
    
	// Constructor
	Protoss(double minerals,double vespene, int num_workers, int num_main);
	
	//Destructor
	~Protoss(){}

    void fileRead(const std::string filename); // khudka

	virtual void workerAssignment() override ; // khudka

	virtual bool buildNext(const std::string name) override ; // khudka
    
	virtual void energyUpdate() override ; // khudka

	virtual void processQueues() override ; // khudka
    
    virtual bool isBuildListValid(const std::vector<std::string> &build_list) override;
};
