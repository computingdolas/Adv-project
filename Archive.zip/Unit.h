#pragma once 
#include <iostream>
#include <string>

// class definition 
class Unit
{

public:
	//properties 
	std::string name;
	bool busy;
	 
	bool busy_with_mineral;
	bool busy_with_vespene;
	bool busy_with_building;

	int time_left;
	Unit(const std::string unit_name, int time){
		name = unit_name;
		time_left = time;
		
		busy=false;
		
		busy_with_building = false;
		busy_with_mineral = false ;
	 	busy_with_vespene = false ;

	}
	~Unit(){

	}

};