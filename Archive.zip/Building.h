#pragma once 
#include <iostream>
#include <string>

class Building
{
public:
	
	// properties  

	std::string name;
	std::string race_name;
	
	int load;
	int max_load;

	bool busy = false ;

	//On hold-not known why
	bool limit = false ;

	int time_left;
	//methods

	Building(const std::string building_name, const std::string race,int time){
		time_left = time;

		name = building_name;
		race_name = race;

		busy = 	false ;
		limit = false ;

		load = 0;
		
		max_load = 1;
	}

	~Building(){

	}
};