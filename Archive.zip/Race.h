//Abstract virtual class from which both Terran and Protoss will be derived
#pragma once

#include <iostream>
#include <vector>
#include <map>
#include <string>
#include <fstream>
#include <sstream>
#include <list>
#include <boost/algorithm/string.hpp>
#include "Building.h"
#include "BuildingData.h"
#include "Unit.h"

using namespace std;
using namespace boost::algorithm;

// class definition 

class Race
{

public:
	std::string race_name;
    
	// Parameter declaration
	double minerals =0.0;
	double vespene =0.0;
	int supply =0;
	double energy=0.0;
	int global_time = 1;
	double rate_energy=0.0,rate_minerals=0.0,rate_vespene = 0.0;

	//Containers to store all the buildings/units that exist currently
	std::vector<Building> buildings;
	std::vector<Unit> units;

	//Maps to store the count of units/buildings. Key is the name of the respective unit/building.
	std::map<std::string,int> count_units;
	std::map<std::string,int> count_buildings;

	//Maps to store the count of probes busy with resources/buildings
	std::map<std::string,int> count_busy_workers;

	//Map containing all the data read from techtrees.csv 
	std::map<std::string,BuildingData> database_units;
	std::map<std::string,BuildingData> database_buildings;

	std::vector<std::pair<Unit,int>> units_queue;

	// Constructor
	Race(double minerals,double vespene, int num_workers, int num_main);

    virtual ~Race(){

	}

	int countBuildings(const std::string name); // common

	int countUnits(const std::string name); // common

	int countFreeUnits(const std::string name); // common

	int countFreeBuildings(const std::string name); // common

	virtual void workerAssignment() = 0;

	virtual bool buildNext(const std::string name) = 0;

	virtual void processQueues() = 0;

	void updateResources(); // common 

	virtual void energyUpdate() = 0;

	//Check all units busy with extraction and deduct 
	void mineralExtract(); // common

	void vespeneExtract(); // common

	void printDatabase(); // common
	
	//Utility functions
	bool findBuilding(std::string name_check); // common

	bool findUnit(std::string name_check);// common

	bool isBuilding(const std::string name_check); // common

	bool isUnit(const std::string name_check);// common

	int findFreeBuilding(std::string building_name); // common

	int findFreeUnit(std::string unit_name); // common

	void setFree(const int producer_rank, bool what);// common

	void setBusy(const int producer_rank, bool what); // common
    
    virtual bool isBuildListValid(const std::vector<std::string> &build_list) =0;
    
    int supplyUsed();

};